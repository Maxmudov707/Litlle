<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $date = htmlspecialchars($_POST['date']);
    $time = htmlspecialchars($_POST['time']);
    $people = htmlspecialchars($_POST['people']);

    // Example: Save data to a file or a database
    $file = 'bookings.txt'; // This is a simple text file, replace with database code as needed
    $booking = "Name: $name\nEmail: $email\nPhone: $phone\nDate: $date\nTime: $time\nPeople: $people\n\n";
    file_put_contents($file, $booking, FILE_APPEND);

    echo "Booking confirmed! We have received your details.";
}
?>
